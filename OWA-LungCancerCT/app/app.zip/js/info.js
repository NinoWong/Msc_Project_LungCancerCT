angular.module('main', [])
  .controller('InfoController', ['$scope', '$http', function($scope, $http) {
    // Function to fetch patient information based on UUID
    $scope.getPatientInfo = function() {
      // Replace 'UUID' with the actual patient's UUID obtained from search results
      const patientUUID = 'UUID';
      const apiUrl = 'http://localhost:8081/openmrs-standalone/ws/rest/v1/patient/' + patientUUID;

      $http.get(apiUrl)
        .then(function(response) {
          // Update the $scope.patient object with the actual data obtained from the API
          $scope.patient = {
            id: response.data.uuid,
            name: response.data.display,
            age: response.data.age,
            birthday: response.data.birthdate.slice(0, 10),
            gender: response.data.gender,
            address: response.data.address,
            // Add other patient information properties as needed
          };
        })
        .catch(function(error) {
          console.log('Error:', error);
        });
    };

    // Call the function to fetch patient information
    $scope.getPatientInfo();

    // Function to go back to the previous page
    $scope.goBack = function() {
      // Add the logic to go back to the previous page here
      // For example:
      // window.history.back();
    };
  }]);
